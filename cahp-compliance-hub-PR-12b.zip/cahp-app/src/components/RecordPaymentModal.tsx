import { useState, useMemo } from 'react';
import {
  useSharePointList,
  updateListItem,
  LIST_NAMES,
  type Disbursement,
  type Owner,
  type DisbursementStatus,
  type DisbPaymentMethod,
  type Ownership,
  type Property,
  computeBeneficialOwnership,
} from '../lib/sharepoint';

const PAYMENT_METHODS: DisbPaymentMethod[] = ['ACH', 'Check', 'Wire', 'Other'];

export interface RecordPaymentModalProps {
  disbursement: Disbursement;
  onClose: () => void;
  onSuccess: () => void;
}

/**
 * Record Payment Modal — per spec §3.11.2.
 *
 * Transitions a Disbursement from Pending → Issued.
 * Captures payment date, method, check # (if Check), and owner allocation.
 *
 * If the disbursement has no owner set, we suggest top beneficial owners from the
 * property's ownership tree so the user can pick the right recipient.
 */
export function RecordPaymentModal({
  disbursement,
  onClose,
  onSuccess,
}: RecordPaymentModalProps) {
  const ownership = useSharePointList<Ownership>(LIST_NAMES.Ownership, { top: 500 });
  const owners = useSharePointList<Owner>(LIST_NAMES.Owners, { top: 500 });
  const properties = useSharePointList<Property>(LIST_NAMES.Properties, { top: 500 });

  // Form state
  const [paymentDate, setPaymentDate] = useState(new Date().toISOString().slice(0, 10));
  const [paymentMethod, setPaymentMethod] = useState<DisbPaymentMethod>('ACH');
  const [checkNumber, setCheckNumber] = useState('');
  const [ownerId, setOwnerId] = useState<string>(disbursement.fields.DisbOwnerLookupId ?? '');
  const [notes, setNotes] = useState('');

  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Compute suggested owners (top beneficial owners from this property's tree)
  const suggestedOwners = useMemo(() => {
    if (!ownership.data || !owners.data || !disbursement.fields.DisbPropertyLookupId) return [];
    try {
      const flat = computeBeneficialOwnership(
        'property',
        String(disbursement.fields.DisbPropertyLookupId),
        ownership.data,
        owners.data
      );
      return flat
        .filter((o) => o.owner)
        .sort((a, b) => b.beneficialPercent - a.beneficialPercent)
        .slice(0, 8);
    } catch {
      return [];
    }
  }, [ownership.data, owners.data, disbursement.fields.DisbPropertyLookupId]);

  const property = useMemo(() => {
    if (!properties.data || !disbursement.fields.DisbPropertyLookupId) return null;
    return properties.data.find((p) => String(p.id) === String(disbursement.fields.DisbPropertyLookupId)) ?? null;
  }, [properties.data, disbursement.fields.DisbPropertyLookupId]);

  const sortedAllOwners = useMemo(() => {
    if (!owners.data) return [];
    return [...owners.data].sort((a, b) => (a.fields.Title ?? '').localeCompare(b.fields.Title ?? ''));
  }, [owners.data]);

  const handleSubmit = async () => {
    setError(null);

    // Validate
    if (!paymentDate) {
      setError('Payment date is required.');
      return;
    }
    if (paymentMethod === 'Check' && !checkNumber.trim()) {
      setError('Check number is required when method is Check.');
      return;
    }

    setSaving(true);
    try {
      const updates: Record<string, unknown> = {
        DisbStatus: 'Issued' as DisbursementStatus,
        DisbIssueDate: new Date(paymentDate).toISOString(),
        DisbPaymentMethod: paymentMethod,
      };
      if (checkNumber) updates.DisbCheckNum = checkNumber;
      if (ownerId) updates.DisbOwnerLookupId = ownerId;
      if (notes) {
        const existing = disbursement.fields.DisbNotes ?? '';
        const newLine = `[Paid ${new Date(paymentDate).toLocaleDateString()}] ${notes}`;
        updates.DisbNotes = existing ? `${existing}\n\n${newLine}` : newLine;
      }
      await updateListItem(LIST_NAMES.Disbursements, disbursement.id, updates);
      onSuccess();
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
      setSaving(false);
    }
  };

  const inputClass =
    'w-full px-2 py-1.5 border border-gray-300 rounded text-sm focus:outline-none focus:border-teal-500 focus:ring-1 focus:ring-teal-500';

  return (
    <div className="fixed inset-0 bg-black/40 flex items-center justify-center p-4 z-50 overflow-y-auto">
      <div className="bg-white rounded-lg shadow-xl max-w-lg w-full p-5 my-8">
        <h3 className="text-lg font-bold text-teal-700 mb-1">Record Payment</h3>
        <p className="text-sm text-gray-600 mb-4">
          Cut a check or send ACH for <strong>{disbursement.fields.Title}</strong>
          {property && <> · {property.fields.Title}</>}
          {disbursement.fields.DisbAmount != null && (
            <> · <span className="font-mono-data font-semibold text-teal-700">${disbursement.fields.DisbAmount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span></>
          )}
          . This transitions status <strong>Pending → Issued</strong>.
        </p>

        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1">
                Payment Date <span className="text-error">*</span>
              </label>
              <input
                type="date"
                value={paymentDate}
                onChange={(e) => setPaymentDate(e.target.value)}
                disabled={saving}
                className={`${inputClass} font-mono-data`}
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1">
                Payment Method <span className="text-error">*</span>
              </label>
              <select
                value={paymentMethod}
                onChange={(e) => setPaymentMethod(e.target.value as DisbPaymentMethod)}
                disabled={saving}
                className={`${inputClass} bg-white`}
              >
                {PAYMENT_METHODS.map((m) => (
                  <option key={m} value={m}>{m}</option>
                ))}
              </select>
            </div>
          </div>

          {paymentMethod === 'Check' && (
            <div>
              <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1">
                Check Number <span className="text-error">*</span>
              </label>
              <input
                type="text"
                value={checkNumber}
                onChange={(e) => setCheckNumber(e.target.value)}
                disabled={saving}
                placeholder="e.g., 1247"
                className={`${inputClass} font-mono-data`}
              />
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1">
              Recipient (Owner)
            </label>
            <select
              value={ownerId}
              onChange={(e) => setOwnerId(e.target.value)}
              disabled={saving}
              className={`${inputClass} bg-white`}
            >
              <option value="">— pick recipient —</option>
              {suggestedOwners.length > 0 && (
                <optgroup label="Suggested (beneficial owners of this property)">
                  {suggestedOwners.map((s) => (
                    <option key={`s-${s.owner!.id}`} value={s.owner!.id}>
                      {s.owner!.fields.Title} ({s.beneficialPercent.toFixed(2)}%)
                    </option>
                  ))}
                </optgroup>
              )}
              <optgroup label="All owners">
                {sortedAllOwners.map((o) => (
                  <option key={o.id} value={o.id}>{o.fields.Title}</option>
                ))}
              </optgroup>
            </select>
            <p className="text-[11px] text-gray-400 mt-0.5">
              Suggested list shows top beneficial owners of this property.
              For 1099 tracking, cumulative payments to one recipient over $600/year flag for tax reporting.
            </p>
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1">
              Notes
            </label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              disabled={saving}
              rows={2}
              placeholder="Optional payment notes — will be appended to disbursement notes"
              className={`${inputClass} resize-y`}
            />
          </div>
        </div>

        {/* What will happen */}
        <div className="mt-4 bg-gold-50 border border-gold-200 rounded-md p-3">
          <div className="text-[10px] font-semibold text-gold-900 uppercase tracking-wider mb-1">
            On Confirm
          </div>
          <ul className="text-xs text-teal-900 space-y-0.5">
            <li>• Status → <strong>Issued</strong></li>
            <li>• Issue Date = {new Date(paymentDate || new Date()).toLocaleDateString()}</li>
            <li>• Payment Method = {paymentMethod}{checkNumber && ` (Check #${checkNumber})`}</li>
            <li>• Audit log entry written</li>
          </ul>
          <p className="text-[11px] text-gray-600 mt-2 italic">
            When the bank confirms the funds cleared, come back and flip status to Cleared with the clear date.
          </p>
        </div>

        {error && (
          <div className="mt-3 bg-red-50 border border-red-200 rounded-md p-2 text-xs text-red-800">
            {error}
          </div>
        )}

        <div className="flex items-center justify-end gap-2 mt-5">
          <button
            onClick={onClose}
            disabled={saving}
            className="px-3 py-1.5 border border-gray-300 text-gray-700 hover:bg-gray-50 rounded-md text-sm font-medium disabled:opacity-50"
          >
            Cancel
          </button>
          <button
            onClick={handleSubmit}
            disabled={saving}
            className="px-4 py-1.5 bg-teal-700 hover:bg-teal-900 text-white rounded-md text-sm font-medium flex items-center gap-1.5 transition-colors disabled:opacity-50"
          >
            {saving && <div className="w-3 h-3 rounded-full border-2 border-white border-r-transparent animate-spin" />}
            {saving ? 'Recording…' : 'Record Payment'}
          </button>
        </div>
      </div>
    </div>
  );
}
